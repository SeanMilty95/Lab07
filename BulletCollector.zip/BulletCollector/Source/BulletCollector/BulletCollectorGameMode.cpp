// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

#include "BulletCollectorGameMode.h"
#include "BulletCollectorCharacter.h"
#include "UObject/ConstructorHelpers.h"
#include "Kismet/GameplayStatics.h"

ABulletCollectorGameMode::ABulletCollectorGameMode()
{
	PrimaryActorTick.bCanEverTick = true;
	// set default pawn class to our Blueprinted character
	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnBPClass(TEXT("/Game/ThirdPersonCPP/Blueprints/ThirdPersonCharacter"));
	if (PlayerPawnBPClass.Class != NULL)
	{
		DefaultPawnClass = PlayerPawnBPClass.Class;
	}

	//base decay rate
	DecayRate = 0.01f;
}

void ABulletCollectorGameMode::Tick(float DeltaTime) {
	Super::Tick(DeltaTime);

	//Check that we are using the correct character
	ABulletCollectorCharacter* MyCharacter = Cast<ABulletCollectorCharacter>(UGameplayStatics::GetPlayerPawn(this, 0));
	if (MyCharacter) {
		// if the character power is positive
		if (MyCharacter->GetCurrentPower() > 0) {
			// decrease the characters power using the decay rate
			MyCharacter->UpdatePower(-DeltaTime*DecayRate*(MyCharacter->GetInitialPower()));
		}
	}
}
