// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Pickup.h"
#include "BatteryPickup.generated.h"

/**
 * 
 */
UCLASS()
class BULLETCOLLECTOR_API ABatteryPickup : public APickup
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ABatteryPickup();

	//Public way to access battery's power level
	float GetPower();
	
	//Override the wascollected function - use Implementation because it is a blueprint native event
	void WasCollected_Implementation() override;
protected:
	//Set the amount of power the battery gives to the character
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="power", meta=(BlueprintProtected="true"))
	float BatteryPower;

};
