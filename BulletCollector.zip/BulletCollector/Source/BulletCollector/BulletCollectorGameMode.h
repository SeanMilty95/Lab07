// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "BulletCollectorGameMode.generated.h"

UCLASS(minimalapi)
class ABulletCollectorGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	ABulletCollectorGameMode();

	virtual void Tick(float DeltaTime) override;

protected:
	//Rate at which the character loses power
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category="Power")
	float DecayRate;
};



